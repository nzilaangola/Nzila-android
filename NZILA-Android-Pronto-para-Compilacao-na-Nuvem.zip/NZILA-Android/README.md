# NZILA Empréstimo — projeto Android nativo

Projeto Android em Kotlin + Jetpack Compose, pacote `ao.nzila.emprestimo`.

## Incluído nesta versão de trabalho
- Aplicativo Android nativo (não é site, não é WebView).
- Logótipo NZILA já incluído no projeto.
- Configuração Firebase fornecida: projeto `nzila-emprestimo-2026`.
- Ecrãs iniciais de acesso, verificação SMS integrada com Firebase Phone Auth, início, simulação, reembolsos e área pessoal.
- Formulário de candidatura em três passos com nome, BI, nascimento, emprego, rendimento, residência, telefone principal, telefone alternativo, IBAN, banco e titular da conta.
- Validação local dos campos obrigatórios e formato de IBAN angolano (AO + 23 dígitos).

## Estado real
Esta é uma base de desenvolvimento, ainda não um APK pronto para clientes. A autenticação por telefone usa Firebase Phone Auth no código-fonte. A palavra-passe ainda não está ligada a um mecanismo seguro de autenticação; não deve ser considerada ativa. A validação do formulário ainda acontece no próprio ecrã e não envia dados para a administração. Firestore/Storage, notificações, decisões administrativas, pagamentos, reembolsos, regras de segurança e testes reais ainda precisam de implementação.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `NZILA-Empréstimo-Android` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação dos componentes Android SDK 35.
4. Execute primeiro num emulador ou telefone de teste.

O ambiente de compilação precisa de Android SDK 35, JDK compatível e acesso aos repositórios Gradle. O APK só deve ser distribuído depois de autenticação real, backend, segurança, política de privacidade, condições de crédito e testes estarem concluídos.


## Configuração obrigatória antes de testar SMS real
- No Firebase Console, confirme que o provedor Telefone está ativado.
- Em Configurações do projeto > Seus apps > app Android, registe os certificados SHA-1 e SHA-256 do app de desenvolvimento/assinatura.
- Confirme que o package name é `ao.nzila.emprestimo` e que `app/google-services.json` pertence ao projeto `nzila-emprestimo-2026`.
- Teste primeiro com números de telefone de teste configurados no Firebase; depois valide o envio SMS real, limites e custos aplicáveis.
- O código atual confirma o telefone com Firebase. A autenticação adicional por palavra-passe exige desenho seguro no backend; nunca guardar palavra-passe em texto simples no Firestore.
