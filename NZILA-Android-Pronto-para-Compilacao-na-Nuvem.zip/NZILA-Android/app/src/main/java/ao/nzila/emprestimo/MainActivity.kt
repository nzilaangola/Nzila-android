package ao.nzila.emprestimo

import android.os.Bundle
import android.app.Activity
import androidx.activity.ComponentActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val NzilaGreen = Color(0xFF145C38)
private val PaleGreen = Color(0xFFEAF3ED)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NzilaApp(this) }
    }
}

@Composable
fun NzilaApp(activity: Activity) {
    val auth = remember { FirebaseAuth.getInstance() }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }
    var verified by remember { mutableStateOf(auth.currentUser != null) }
    var page by remember { mutableStateOf("Início") }
    var showSupport by remember { mutableStateOf(false) }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var authMessage by remember { mutableStateOf("") }

    fun finishSignIn(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnSuccessListener {
                signedIn = true
                verified = true
                authMessage = "Conta confirmada com sucesso."
            }
            .addOnFailureListener { error ->
                authMessage = error.localizedMessage ?: "Não foi possível confirmar o código."
            }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = NzilaGreen, secondary = NzilaGreen, background = Color(0xFFF7F9F7))) {
        if (!signedIn || !verified) {
            if (verificationId == null) {
                LoginScreen(authMessage = authMessage, onRequestCode = { rawPhone, _ ->
                    val phone = rawPhone.trim().replace(" ", "")
                    authMessage = "A solicitar código SMS..."
                    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                            finishSignIn(credential)
                        }
                        override fun onVerificationFailed(e: FirebaseException) {
                            authMessage = e.localizedMessage ?: "Falha ao enviar SMS. Verifique o número e a configuração Firebase."
                        }
                        override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                            verificationId = id
                            authMessage = "Código enviado. Consulte as suas mensagens SMS."
                        }
                    }
                    try {
                        val options = PhoneAuthOptions.newBuilder(auth)
                            .setPhoneNumber(phone)
                            .setTimeout(60L, TimeUnit.SECONDS)
                            .setActivity(activity)
                            .setCallbacks(callbacks)
                            .build()
                        PhoneAuthProvider.verifyPhoneNumber(options)
                    } catch (e: Exception) {
                        authMessage = e.localizedMessage ?: "Número inválido. Use o formato internacional, por exemplo +244..."
                    }
                })
            } else {
                OtpScreen(authMessage = authMessage, onConfirm = { code ->
                    val id = verificationId
                    if (id.isNullOrBlank()) {
                        authMessage = "Solicite um novo código SMS."
                    } else {
                        val credential = PhoneAuthProvider.getCredential(id, code.trim())
                        finishSignIn(credential)
                    }
                })
            }
        } else Scaffold(
            containerColor = Color(0xFFF7F9F7),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Início", "Empréstimo", "Reembolsar", "Pessoal").forEach { item ->
                        NavigationBarItem(selected = page == item, onClick = { page = item },
                            icon = { Icon(when(item) { "Início" -> Icons.Default.Home; "Empréstimo" -> Icons.Default.AccountBalance; "Reembolsar" -> Icons.Default.Payments; else -> Icons.Default.Person }, contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) })
                    }
                }
            }, floatingActionButton = {
                ExtendedFloatingActionButton(onClick = { showSupport = true }, containerColor = NzilaGreen, contentColor = Color.White,
                    icon = { Icon(Icons.Default.SupportAgent, null) }, text = { Text("Apoio") })
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when(page) {
                    "Início" -> HomeScreen(onApply = { page = "Empréstimo" })
                    "Empréstimo" -> LoanFormScreen()
                    "Reembolsar" -> RepaymentScreen()
                    else -> PersonalScreen(onSupport = { showSupport = true })
                }
            }
            if (showSupport) AlertDialog(onDismissRequest = { showSupport = false }, title = { Text("Apoio ao cliente") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Escolha como pretende contactar a equipa NZILA:")
                    SupportChoice("E-mail", "Endereço a fornecer", Icons.Default.Email)
                    SupportChoice("WhatsApp", "Número a fornecer", Icons.Default.Chat)
                    SupportChoice("Chamada telefónica", "Número a fornecer", Icons.Default.Call)
                } }, confirmButton = { TextButton(onClick = { showSupport = false }) { Text("Fechar") } })
        }
    }
}

@Composable
private fun BrandHeader() {
    Row(Modifier.fillMaxWidth().background(Color.White).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.nzila_logo), contentDescription = "Logótipo NZILA", modifier = Modifier.size(48.dp))
        Spacer(Modifier.width(12.dp))
        Column { Text("NZILA", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = NzilaGreen); Text("EMPRÉSTIMO", fontSize = 11.sp, color = Color.DarkGray) }
    }
}

@Composable
private fun LoginScreen(authMessage: String, onRequestCode: (String, String) -> Unit) {
    var phone by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Color.White), horizontalAlignment = Alignment.CenterHorizontally) {
        BrandHeader(); Spacer(Modifier.height(44.dp))
        Text("Bem-vindo ao NZILA", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = NzilaGreen)
        Text("Entre ou crie a sua conta", color = Color.Gray)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(phone, { phone = it }, label = { Text("Número de telefone com indicativo") }, placeholder = { Text("+244 9XX XXX XXX") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(.88f))
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Palavra-passe") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(.88f))
        Spacer(Modifier.height(22.dp))
        Button(onClick = { onRequestCode(phone, password) }, enabled = phone.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth(.88f).height(52.dp)) { Text("Continuar e confirmar por SMS") }
        if (authMessage.isNotBlank()) Text(authMessage, Modifier.padding(16.dp), color = NzilaGreen, fontSize = 12.sp)
        Text("A confirmação do número é feita pelo Firebase. A camada segura de palavra-passe e recuperação de conta ainda será integrada antes da publicação.", Modifier.padding(20.dp), color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun OtpScreen(authMessage: String, onConfirm: (String) -> Unit) {
    var code by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Color.White).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        BrandHeader(); Spacer(Modifier.height(32.dp)); Text("Confirmar número", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Introduza o código recebido por SMS.", color = Color.Gray)
        OutlinedTextField(code, { code = it.filter(Char::isDigit).take(6) }, label = { Text("Código SMS") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp)); Button(onClick = { onConfirm(code) }, enabled = code.length in 4..6, modifier = Modifier.fillMaxWidth()) { Text("Confirmar") }
        if (authMessage.isNotBlank()) Text(authMessage, Modifier.padding(top = 16.dp), color = NzilaGreen, fontSize = 12.sp)
    }
}

@Composable
private fun HomeScreen(onApply: () -> Unit) {
    var amount by remember { mutableFloatStateOf(100000f) }
    var term by remember { mutableStateOf("30 dias") }
    LazyColumn(Modifier.fillMaxSize()) {
        item { BrandHeader(); Column(Modifier.padding(20.dp)) {
            Text("O seu próximo passo começa aqui", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = NzilaGreen)
            Spacer(Modifier.height(18.dp)); Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(18.dp)) {
                Text("Simular empréstimo", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Valor pretendido", color = Color.Gray); Text("${amount.toInt()} Kz", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = NzilaGreen)
                Slider(value = amount, onValueChange = { amount = it }, valueRange = 20000f..500000f, steps = 23)
                Text("Prazo do empréstimo"); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("15 dias", "30 dias", "3 meses", "6 meses").forEach { FilterChip(selected = term == it, onClick = { term = it }, label = { Text(it) }) } }
                Text("Taxa de juro e custo total: serão apresentados após configuração das condições oficiais.", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(12.dp)); Button(onClick = onApply, modifier = Modifier.fillMaxWidth()) { Text("Obter empréstimo") }
            } }
            Spacer(Modifier.height(14.dp)); Text("Estado da solicitação", fontWeight = FontWeight.Bold); Text("Ainda não tem uma solicitação submetida.", color = Color.Gray)
        } }
    }
}

@Composable
private fun LoanFormScreen() {
    val fieldsByStep = listOf(
        listOf("Nome completo", "Número do Bilhete de Identidade", "Data de nascimento", "Local de trabalho", "Rendimento mensal"),
        listOf("Província", "Município", "Bairro", "Telefone principal", "Telefone alternativo"),
        listOf("IBAN", "Nome do banco", "Nome do titular da conta")
    )
    val values = remember { mutableStateMapOf<String, String>() }
    val errors = remember { mutableStateMapOf<String, String>() }
    var step by remember { mutableIntStateOf(1) }
    var showReadyDialog by remember { mutableStateOf(false) }

    fun validateStep(stepNumber: Int): Boolean {
        var valid = true
        fieldsByStep[stepNumber - 1].forEach { field ->
            val value = values[field].orEmpty().trim()
            if (value.isBlank()) {
                errors[field] = "Este campo é obrigatório."
                valid = false
            } else {
                errors.remove(field)
            }
            if (field == "IBAN" && value.isNotBlank()) {
                val normalizedIban = value.replace(" ", "").uppercase()
                if (!normalizedIban.matches(Regex("AO[0-9]{23}"))) {
                    errors[field] = "Introduza um IBAN angolano válido (AO + 23 dígitos)."
                    valid = false
                }
            }
        }
        return valid
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Pedido de empréstimo", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = NzilaGreen)
            Text("Passo $step de 3", color = Color.Gray)
            LinearProgressIndicator(progress = { step / 3f }, modifier = Modifier.fillMaxWidth())
            Text("Preencha todos os campos assinalados com *. O IBAN e o telefone alternativo são obrigatórios.", color = Color.Gray, fontSize = 12.sp)
        }
        items(fieldsByStep[step - 1]) { field ->
            val value = values[field].orEmpty()
            val fieldError = errors[field]
            val isIban = field == "IBAN"
            val isPhone = field.contains("Telefone")
            val isMoney = field == "Rendimento mensal"
            OutlinedTextField(
                value = value,
                onValueChange = {
                    values[field] = if (isIban) it.uppercase() else it
                    errors.remove(field)
                },
                label = { Text("$field *") },
                placeholder = { if (isIban) Text("AO06...") },
                singleLine = true,
                isError = fieldError != null,
                keyboardOptions = KeyboardOptions(
                    keyboardType = when {
                        isPhone -> KeyboardType.Phone
                        isMoney -> KeyboardType.Number
                        isIban -> KeyboardType.Ascii
                        else -> KeyboardType.Text
                    }
                ),
                supportingText = {
                    if (fieldError != null) Text(fieldError, color = MaterialTheme.colorScheme.error)
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (step > 1) {
                    OutlinedButton(onClick = { step-- }, modifier = Modifier.weight(1f)) { Text("Voltar") }
                }
                Button(
                    onClick = {
                        if (validateStep(step)) {
                            if (step < 3) step++ else showReadyDialog = true
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (step < 3) "Continuar" else "Validar dados")
                }
            }
            Text("A candidatura só poderá ser enviada para análise depois da integração segura com o servidor.", color = Color.Gray, fontSize = 12.sp)
        }
    }

    if (showReadyDialog) {
        AlertDialog(
            onDismissRequest = { showReadyDialog = false },
            title = { Text("Dados validados") },
            text = { Text("Os campos obrigatórios, incluindo o IBAN e o telefone alternativo, foram preenchidos. O envio real da candidatura e a notificação da administração serão ativados na próxima etapa de integração Firebase.") },
            confirmButton = {
                TextButton(onClick = { showReadyDialog = false }) { Text("Entendi") }
            }
        )
    }
}

@Composable
private fun RepaymentScreen() { Column(Modifier.fillMaxSize().padding(20.dp)) { Text("Reembolsar", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = NzilaGreen); Spacer(Modifier.height(12.dp)); Text("Aqui o cliente acompanhará empréstimos ativos, valores em dívida, datas de vencimento e pagamentos confirmados."); Spacer(Modifier.height(16.dp)); Card { Text("Ainda não existem dados de reembolso associados a esta conta.", Modifier.padding(18.dp)) } } }

@Composable
private fun PersonalScreen(onSupport: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Área pessoal", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = NzilaGreen); Text("Consulte e gira a sua conta NZILA.", color = Color.Gray) }
        items(listOf("Os meus dados pessoais", "Política de privacidade", "Feedback", "Definições do aplicativo", "Eliminar os meus dados pessoais", "Encerrar a minha conta", "Apoio ao cliente")) { item ->
            Card(onClick = { if(item == "Apoio ao cliente") onSupport() }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ChevronRight, null, tint = NzilaGreen); Spacer(Modifier.width(8.dp)); Text(item, fontWeight = FontWeight.Medium) }
            }
        }
        item { Text("As opções de eliminação de dados e encerramento de conta serão ligadas ao processo seguro de verificação e tratamento de dados.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun SupportChoice(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = NzilaGreen); Spacer(Modifier.width(10.dp)); Column { Text(title, fontWeight = FontWeight.SemiBold); Text(detail, color = Color.Gray, fontSize = 12.sp) } }
}
